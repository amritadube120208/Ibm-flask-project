"""
Flask web application for the Emotion Detection system.

Routes:
    GET  /           → Serves the main UI page.
    GET  /emotionDetector → Accepts a 'textToAnalyze' query param and
                            returns a formatted emotion analysis string.
"""

from flask import Flask, request, render_template
from EmotionDetection import emotion_detector

app = Flask(__name__)


@app.route('/')
def index():
    """Render the main application page."""
    return render_template('index.html')


@app.route('/emotionDetector')
def emotion_detector_route():
    """
    Analyse the text provided via the 'textToAnalyze' query parameter.

    Returns:
        str: A human-readable summary of the detected emotions, or an
             error message if the input is blank or the API fails.
    """
    text_to_analyze = request.args.get('textToAnalyze', '').strip()

    result = emotion_detector(text_to_analyze)

    # Task 7: Error handling — blank / invalid input
    if result['dominant_emotion'] is None:
        return "Invalid text! Please try again.", 400

    response_text = (
        f"For the given statement, the system response is "
        f"'anger': {result['anger']}, "
        f"'disgust': {result['disgust']}, "
        f"'fear': {result['fear']}, "
        f"'joy': {result['joy']} and "
        f"'sadness': {result['sadness']}. "
        f"The dominant emotion is <b>{result['dominant_emotion']}</b>."
    )

    return response_text


if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
