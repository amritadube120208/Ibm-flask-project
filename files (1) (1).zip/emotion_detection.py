"""
Emotion Detection module using Watson NLP Embed library.
Sends text to the Watson NLP emotion prediction endpoint and
returns a formatted dictionary of the detected emotions and dominant emotion.
"""

import json
import requests


def emotion_detector(text_to_analyze):
    """
    Analyzes the given text and returns emotion scores along with
    the dominant emotion using the Watson NLP Embed API.

    Args:
        text_to_analyze (str): The customer feedback text to analyze.

    Returns:
        dict: A dictionary with keys 'anger', 'disgust', 'fear', 'joy',
              'sadness', and 'dominant_emotion'. Returns None values on
              blank input or API errors.
    """
    # Handle blank/empty input — Task 7: Error handling
    if not text_to_analyze or not text_to_analyze.strip():
        return {
            'anger': None,
            'disgust': None,
            'fear': None,
            'joy': None,
            'sadness': None,
            'dominant_emotion': None
        }

    url = (
        'https://sn-watson-emotion.labs.skills.network/v1/'
        'watson.runtime.nlp.v1/NlpService/EmotionPredict'
    )
    headers = {
        'grpc-metadata-mm-model-id': 'emotion_aggregated-workflow_lang_en_stock',
        'Content-Type': 'application/json'
    }
    payload = {
        "raw_document": {
            "text": text_to_analyze
        }
    }

    try:
        response = requests.post(url, headers=headers, json=payload, timeout=10)

        # Task 7: handle non-200 status codes
        if response.status_code == 400:
            return {
                'anger': None,
                'disgust': None,
                'fear': None,
                'joy': None,
                'sadness': None,
                'dominant_emotion': None
            }

        response.raise_for_status()
        result = json.loads(response.text)

        # Extract emotion scores from nested response
        emotions = result['emotionPredictions'][0]['emotion']
        anger   = emotions.get('anger',   0)
        disgust = emotions.get('disgust', 0)
        fear    = emotions.get('fear',    0)
        joy     = emotions.get('joy',     0)
        sadness = emotions.get('sadness', 0)

        # Determine dominant emotion — Task 3: formatted output
        emotion_scores = {
            'anger':   anger,
            'disgust': disgust,
            'fear':    fear,
            'joy':     joy,
            'sadness': sadness
        }
        dominant_emotion = max(emotion_scores, key=emotion_scores.get)

        return {
            'anger':            anger,
            'disgust':          disgust,
            'fear':             fear,
            'joy':              joy,
            'sadness':          sadness,
            'dominant_emotion': dominant_emotion
        }

    except (requests.exceptions.RequestException, KeyError, IndexError, json.JSONDecodeError):
        return {
            'anger': None,
            'disgust': None,
            'fear': None,
            'joy': None,
            'sadness': None,
            'dominant_emotion': None
        }
