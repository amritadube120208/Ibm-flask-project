"""
Unit tests for the EmotionDetection package.
Uses unittest.mock to simulate Watson NLP API responses.
"""
import json
import unittest
from unittest.mock import patch, MagicMock
from EmotionDetection import emotion_detector


def _mock_response(emotion_scores, status_code=200):
    mock = MagicMock()
    mock.status_code = status_code
    mock.text = json.dumps({"emotionPredictions": [{"emotion": emotion_scores}]})
    mock.raise_for_status = MagicMock()
    return mock


class TestEmotionDetector(unittest.TestCase):

    @patch('EmotionDetection.emotion_detection.requests.post')
    def test_joy_detected_for_positive_statement(self, mock_post):
        """Joy should be the dominant emotion for a clearly happy statement."""
        mock_post.return_value = _mock_response(
            {'anger': 0.05, 'disgust': 0.02, 'fear': 0.03, 'joy': 0.82, 'sadness': 0.08})
        result = emotion_detector("I am glad this happened")
        self.assertEqual(result['dominant_emotion'], 'joy')

    @patch('EmotionDetection.emotion_detection.requests.post')
    def test_anger_detected_for_angry_statement(self, mock_post):
        """Anger should be the dominant emotion for an angry statement."""
        mock_post.return_value = _mock_response(
            {'anger': 0.78, 'disgust': 0.10, 'fear': 0.05, 'joy': 0.02, 'sadness': 0.05})
        result = emotion_detector("I am really angry at this")
        self.assertEqual(result['dominant_emotion'], 'anger')

    @patch('EmotionDetection.emotion_detection.requests.post')
    def test_disgust_detected_for_disgusting_statement(self, mock_post):
        """Disgust should be the dominant emotion for a disgusting statement."""
        mock_post.return_value = _mock_response(
            {'anger': 0.12, 'disgust': 0.70, 'fear': 0.05, 'joy': 0.01, 'sadness': 0.12})
        result = emotion_detector("I feel disgusted just hearing about this")
        self.assertEqual(result['dominant_emotion'], 'disgust')

    @patch('EmotionDetection.emotion_detection.requests.post')
    def test_sadness_detected_for_sad_statement(self, mock_post):
        """Sadness should be the dominant emotion for a sad statement."""
        mock_post.return_value = _mock_response(
            {'anger': 0.08, 'disgust': 0.04, 'fear': 0.10, 'joy': 0.03, 'sadness': 0.75})
        result = emotion_detector("It is really sad how things are")
        self.assertEqual(result['dominant_emotion'], 'sadness')

    @patch('EmotionDetection.emotion_detection.requests.post')
    def test_fear_detected_for_fearful_statement(self, mock_post):
        """Fear should be the dominant emotion for a fearful statement."""
        mock_post.return_value = _mock_response(
            {'anger': 0.06, 'disgust': 0.03, 'fear': 0.80, 'joy': 0.02, 'sadness': 0.09})
        result = emotion_detector("I am scared and terrified")
        self.assertEqual(result['dominant_emotion'], 'fear')

    def test_blank_input_returns_none(self):
        """Blank input should return None for all fields."""
        result = emotion_detector("")
        self.assertIsNone(result['dominant_emotion'])
        self.assertIsNone(result['anger'])

    @patch('EmotionDetection.emotion_detection.requests.post')
    def test_result_has_all_required_keys(self, mock_post):
        """Result must contain all five emotions and dominant_emotion."""
        mock_post.return_value = _mock_response(
            {'anger': 0.05, 'disgust': 0.02, 'fear': 0.03, 'joy': 0.82, 'sadness': 0.08})
        result = emotion_detector("I love this product!")
        self.assertEqual(set(result.keys()),
                         {'anger', 'disgust', 'fear', 'joy', 'sadness', 'dominant_emotion'})


if __name__ == '__main__':
    unittest.main()
